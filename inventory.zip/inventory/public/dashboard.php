<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../helpers/escape.php';

require_login();

$page_title = 'Dashboard';


// ========================================
// TOTAL PRODUK
// ========================================

$stmt = $pdo->query("
    SELECT COUNT(*) AS total
    FROM products
");

$totalProducts = $stmt->fetch()['total'];


// ========================================
// TOTAL NILAI INVENTORY
// ========================================

$stmt = $pdo->query("
    SELECT COALESCE(SUM(price * stock), 0) AS total
    FROM products
");

$inventoryValue = $stmt->fetch()['total'];


// ========================================
// PRODUK STOK MENIPIS
// ========================================

$stmt = $pdo->query("
    SELECT COUNT(*) AS total
    FROM products
    WHERE stock <= minimum_stock
");

$lowStock = $stmt->fetch()['total'];


// ========================================
// TOTAL BARANG MASUK
// ========================================

$stmt = $pdo->query("
    SELECT COALESCE(SUM(quantity), 0) AS total
    FROM stock_movements
    WHERE type = 'IN'
");

$totalIn = $stmt->fetch()['total'];


// ========================================
// TOTAL BARANG KELUAR
// ========================================

$stmt = $pdo->query("
    SELECT COALESCE(SUM(quantity), 0) AS total
    FROM stock_movements
    WHERE type = 'OUT'
");

$totalOut = $stmt->fetch()['total'];


// ========================================
// PRODUK STOK MENIPIS
// ========================================

$stmt = $pdo->query("
    SELECT
        p.id,
        p.sku,
        p.name,
        p.stock,
        p.minimum_stock,
        c.name AS category_name
    FROM products p
    INNER JOIN categories c
        ON c.id = p.category_id
    WHERE p.stock <= p.minimum_stock
    ORDER BY p.stock ASC
    LIMIT 10
");

$lowStockProducts = $stmt->fetchAll();


include __DIR__ . '/../views/header.php';

?>


<!-- ================================ -->
<!-- DASHBOARD CARDS -->
<!-- ================================ -->

<div class="dashboard-grid">

    <div class="dashboard-card">

        <div class="dashboard-card-title">
            Total Produk
        </div>

        <div class="dashboard-card-value">
            <?= e($totalProducts) ?>
        </div>

    </div>


    <div class="dashboard-card">

        <div class="dashboard-card-title">
            Nilai Inventory
        </div>

        <div class="dashboard-card-value">
            Rp <?= number_format($inventoryValue, 0, ',', '.') ?>
        </div>

    </div>


    <div class="dashboard-card">

        <div class="dashboard-card-title">
            Stok Menipis
        </div>

        <div class="dashboard-card-value">
            <?= e($lowStock) ?>
        </div>

    </div>


    <div class="dashboard-card">

        <div class="dashboard-card-title">
            Barang Masuk
        </div>

        <div class="dashboard-card-value">
            <?= e($totalIn) ?>
        </div>

    </div>


    <div class="dashboard-card">

        <div class="dashboard-card-title">
            Barang Keluar
        </div>

        <div class="dashboard-card-value">
            <?= e($totalOut) ?>
        </div>

    </div>

</div>


<!-- ================================ -->
<!-- PRODUK STOK MENIPIS -->
<!-- ================================ -->

<div class="card">

    <div class="card-header">

        <h2>
            Produk dengan Stok Menipis
        </h2>

        <a
            href="products/index.php"
            class="btn btn-primary"
        >
            Lihat Semua Produk
        </a>

    </div>


    <?php if (count($lowStockProducts) > 0): ?>

        <div class="table-responsive">

            <table>

                <thead>

                    <tr>
                        <th>No</th>
                        <th>SKU</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th>Stok</th>
                        <th>Minimum Stok</th>
                    </tr>

                </thead>


                <tbody>

                    <?php foreach ($lowStockProducts as $index => $product): ?>

                        <tr>

                            <td>
                                <?= $index + 1 ?>
                            </td>

                            <td>
                                <?= e($product['sku']) ?>
                            </td>

                            <td>
                                <?= e($product['name']) ?>
                            </td>

                            <td>
                                <?= e($product['category_name']) ?>
                            </td>

                            <td>

                                <span class="stock-warning">
                                    <?= e($product['stock']) ?>
                                </span>

                            </td>

                            <td>
                                <?= e($product['minimum_stock']) ?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    <?php else: ?>

        <div class="empty-state">

            <p>
                Tidak ada produk dengan stok menipis.
            </p>

        </div>

    <?php endif; ?>

</div>


<?php

include __DIR__ . '/../views/footer.php';

?>