<?php

require_once __DIR__ . '/../config/database.php';

$password = password_hash('password', PASSWORD_DEFAULT);

$stmt = $pdo->prepare("
    UPDATE users
    SET password = ?
    WHERE username IN ('admin', 'staff')
");

$stmt->execute([$password]);

echo "Password berhasil diubah menjadi: password";