<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';

require_admin();

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {

    $_SESSION['error'] = 'ID supplier tidak valid.';

    header('Location: index.php');
    exit;
}


// Cek apakah supplier masih terhubung dengan produk

$stmt = $pdo->prepare("
    SELECT COUNT(*) AS total
    FROM product_suppliers
    WHERE supplier_id = ?
");

$stmt->execute([$id]);

$totalProducts = $stmt->fetch()['total'];


if ($totalProducts > 0) {

    $_SESSION['error'] =
        'Supplier tidak dapat dihapus karena masih terhubung dengan produk.';

    header('Location: index.php');
    exit;
}


// Hapus supplier

$stmt = $pdo->prepare("
    DELETE FROM suppliers
    WHERE id = ?
");

$stmt->execute([$id]);

$_SESSION['success'] =
    'Supplier berhasil dihapus.';

header('Location: index.php');
exit;