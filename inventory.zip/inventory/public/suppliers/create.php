<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_admin();

$page_title = 'Tambah Supplier';

$error = '';

$name = '';
$phone = '';
$address = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');


    if ($name === '') {

        $error = 'Nama supplier wajib diisi.';

    } else {

        $stmt = $pdo->prepare("
            INSERT INTO suppliers
            (
                name,
                phone,
                address
            )
            VALUES (?, ?, ?)
        ");

        $stmt->execute([
            $name,
            $phone,
            $address
        ]);

        $_SESSION['success'] =
            'Supplier berhasil ditambahkan.';

        header('Location: index.php');
        exit;
    }
}

include __DIR__ . '/../../views/header.php';

?>

<div class="card">

    <div class="card-header">

        <h2>Tambah Supplier</h2>

    </div>


    <?php if ($error !== ''): ?>

        <div class="alert alert-danger">
            <?= e($error) ?>
        </div>

    <?php endif; ?>


    <form method="POST">

        <div class="form-group">

            <label for="name">
                Nama Supplier
            </label>

            <input
                type="text"
                id="name"
                name="name"
                value="<?= e($name) ?>"
                placeholder="Contoh: PT Sumber Jaya"
                required
            >

        </div>


        <div class="form-group">

            <label for="phone">
                No. Telepon
            </label>

            <input
                type="text"
                id="phone"
                name="phone"
                value="<?= e($phone) ?>"
                placeholder="Contoh: 081234567890"
            >

        </div>


        <div class="form-group">

            <label for="address">
                Alamat
            </label>

            <textarea
                id="address"
                name="address"
                rows="4"
                placeholder="Masukkan alamat supplier"
            ><?= e($address) ?></textarea>

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Simpan
            </button>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                Kembali
            </a>

        </div>

    </form>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>