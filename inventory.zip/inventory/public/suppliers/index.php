<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_login();

$page_title = 'Supplier';

$stmt = $pdo->query("
    SELECT
        s.id,
        s.name,
        s.phone,
        s.address,
        s.created_at,
        COUNT(ps.product_id) AS total_products
    FROM suppliers s
    LEFT JOIN product_suppliers ps
        ON ps.supplier_id = s.id
    GROUP BY
        s.id,
        s.name,
        s.phone,
        s.address,
        s.created_at
    ORDER BY s.name ASC
");

$suppliers = $stmt->fetchAll();

include __DIR__ . '/../../views/header.php';

?>

<div class="card">

    <div class="card-header">

        <h2>Data Supplier</h2>

        <?php if (is_admin()): ?>

            <a
                href="create.php"
                class="btn btn-primary"
            >
                + Tambah Supplier
            </a>

        <?php endif; ?>

    </div>


    <div class="table-responsive">

        <table>

            <thead>

                <tr>
                    <th>No</th>
                    <th>Nama Supplier</th>
                    <th>No. Telepon</th>
                    <th>Alamat</th>
                    <th>Jumlah Produk</th>

                    <?php if (is_admin()): ?>
                        <th>Aksi</th>
                    <?php endif; ?>

                </tr>

            </thead>

            <tbody>

                <?php if (count($suppliers) > 0): ?>

                    <?php foreach ($suppliers as $index => $supplier): ?>

                        <tr>

                            <td>
                                <?= $index + 1 ?>
                            </td>

                            <td>
                                <?= e($supplier['name']) ?>
                            </td>

                            <td>
                                <?= e($supplier['phone'] ?? '-') ?>
                            </td>

                            <td>
                                <?= e($supplier['address'] ?? '-') ?>
                            </td>

                            <td>
                                <?= e($supplier['total_products']) ?>
                            </td>


                            <?php if (is_admin()): ?>

                                <td>

                                    <a
                                        href="edit.php?id=<?= e($supplier['id']) ?>"
                                        class="btn btn-small btn-warning"
                                    >
                                        Edit
                                    </a>

                                    <a
                                        href="delete.php?id=<?= e($supplier['id']) ?>"
                                        class="btn btn-small btn-danger"
                                        onclick="return confirm('Yakin ingin menghapus supplier ini?')"
                                    >
                                        Hapus
                                    </a>

                                </td>

                            <?php endif; ?>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="<?= is_admin() ? 6 : 5 ?>"
                            class="text-center"
                        >
                            Belum ada supplier.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>