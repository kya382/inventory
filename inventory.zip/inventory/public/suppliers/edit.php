<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_admin();

$page_title = 'Edit Supplier';

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {

    $_SESSION['error'] = 'ID supplier tidak valid.';

    header('Location: index.php');
    exit;
}


// Ambil data supplier

$stmt = $pdo->prepare("
    SELECT *
    FROM suppliers
    WHERE id = ?
");

$stmt->execute([$id]);

$supplier = $stmt->fetch();

if (!$supplier) {

    $_SESSION['error'] = 'Supplier tidak ditemukan.';

    header('Location: index.php');
    exit;
}


$error = '';

$name = $supplier['name'];
$phone = $supplier['phone'];
$address = $supplier['address'];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');


    if ($name === '') {

        $error = 'Nama supplier wajib diisi.';

    } else {

        $stmt = $pdo->prepare("
            UPDATE suppliers
            SET
                name = ?,
                phone = ?,
                address = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $name,
            $phone,
            $address,
            $id
        ]);

        $_SESSION['success'] =
            'Supplier berhasil diperbarui.';

        header('Location: index.php');
        exit;
    }
}

include __DIR__ . '/../../views/header.php';

?>

<div class="card">

    <div class="card-header">

        <h2>Edit Supplier</h2>

    </div>


    <?php if ($error !== ''): ?>

        <div class="alert alert-danger">
            <?= e($error) ?>
        </div>

    <?php endif; ?>


    <form method="POST">

        <div class="form-group">

            <label for="name">
                Nama Supplier
            </label>

            <input
                type="text"
                id="name"
                name="name"
                value="<?= e($name) ?>"
                required
            >

        </div>


        <div class="form-group">

            <label for="phone">
                No. Telepon
            </label>

            <input
                type="text"
                id="phone"
                name="phone"
                value="<?= e($phone) ?>"
            >

        </div>


        <div class="form-group">

            <label for="address">
                Alamat
            </label>

            <textarea
                id="address"
                name="address"
                rows="4"
            ><?= e($address) ?></textarea>

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Update
            </button>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                Kembali
            </a>

        </div>

    </form>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>