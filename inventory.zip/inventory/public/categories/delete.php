<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';

require_admin();

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {

    $_SESSION['error'] = 'ID kategori tidak valid.';

    header('Location: index.php');
    exit;
}


// Cek apakah kategori masih digunakan produk

$stmt = $pdo->prepare("
    SELECT COUNT(*) AS total
    FROM products
    WHERE category_id = ?
");

$stmt->execute([$id]);

$totalProducts = $stmt->fetch()['total'];


if ($totalProducts > 0) {

    $_SESSION['error'] =
        'Kategori tidak dapat dihapus karena masih digunakan oleh produk.';

    header('Location: index.php');
    exit;
}


// Hapus kategori

$stmt = $pdo->prepare("
    DELETE FROM categories
    WHERE id = ?
");

$stmt->execute([$id]);

$_SESSION['success'] = 'Kategori berhasil dihapus.';

header('Location: index.php');
exit;