<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_admin();

$page_title = 'Tambah Kategori';

$error = '';

$name = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');

    if ($name === '') {

        $error = 'Nama kategori wajib diisi.';

    } else {

        $stmt = $pdo->prepare("
            SELECT id
            FROM categories
            WHERE name = ?
            LIMIT 1
        ");

        $stmt->execute([$name]);

        if ($stmt->fetch()) {

            $error = 'Kategori tersebut sudah ada.';

        } else {

            $stmt = $pdo->prepare("
                INSERT INTO categories (name)
                VALUES (?)
            ");

            $stmt->execute([$name]);

            $_SESSION['success'] = 'Kategori berhasil ditambahkan.';

            header('Location: index.php');
            exit;
        }
    }
}

include __DIR__ . '/../../views/header.php';

?>

<div class="card">

    <div class="card-header">

        <h2>Tambah Kategori</h2>

    </div>


    <?php if ($error !== ''): ?>

        <div class="alert alert-danger">
            <?= e($error) ?>
        </div>

    <?php endif; ?>


    <form method="POST">

        <div class="form-group">

            <label for="name">
                Nama Kategori
            </label>

            <input
                type="text"
                id="name"
                name="name"
                value="<?= e($name) ?>"
                placeholder="Contoh: Elektronik"
                required
            >

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Simpan
            </button>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                Kembali
            </a>

        </div>

    </form>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>