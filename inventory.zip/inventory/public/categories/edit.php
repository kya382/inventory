<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_admin();

$page_title = 'Edit Kategori';

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {

    $_SESSION['error'] = 'ID kategori tidak valid.';

    header('Location: index.php');
    exit;
}


// Ambil data kategori

$stmt = $pdo->prepare("
    SELECT *
    FROM categories
    WHERE id = ?
");

$stmt->execute([$id]);

$category = $stmt->fetch();

if (!$category) {

    $_SESSION['error'] = 'Kategori tidak ditemukan.';

    header('Location: index.php');
    exit;
}


$error = '';

$name = $category['name'];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name'] ?? '');

    if ($name === '') {

        $error = 'Nama kategori wajib diisi.';

    } else {

        $stmt = $pdo->prepare("
            SELECT id
            FROM categories
            WHERE name = ?
            AND id != ?
            LIMIT 1
        ");

        $stmt->execute([$name, $id]);

        if ($stmt->fetch()) {

            $error = 'Nama kategori sudah digunakan.';

        } else {

            $stmt = $pdo->prepare("
                UPDATE categories
                SET name = ?
                WHERE id = ?
            ");

            $stmt->execute([$name, $id]);

            $_SESSION['success'] = 'Kategori berhasil diperbarui.';

            header('Location: index.php');
            exit;
        }
    }
}

include __DIR__ . '/../../views/header.php';

?>

<div class="card">

    <div class="card-header">

        <h2>Edit Kategori</h2>

    </div>


    <?php if ($error !== ''): ?>

        <div class="alert alert-danger">
            <?= e($error) ?>
        </div>

    <?php endif; ?>


    <form method="POST">

        <div class="form-group">

            <label for="name">
                Nama Kategori
            </label>

            <input
                type="text"
                id="name"
                name="name"
                value="<?= e($name) ?>"
                required
            >

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Update
            </button>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                Kembali
            </a>

        </div>

    </form>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>