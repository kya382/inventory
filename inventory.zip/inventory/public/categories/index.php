<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_login();

$page_title = 'Kategori';

$stmt = $pdo->query("
    SELECT
        c.id,
        c.name,
        c.created_at,
        COUNT(p.id) AS total_products
    FROM categories c
    LEFT JOIN products p
        ON p.category_id = c.id
    GROUP BY c.id, c.name, c.created_at
    ORDER BY c.name ASC
");

$categories = $stmt->fetchAll();

include __DIR__ . '/../../views/header.php';

?>

<div class="card">

    <div class="card-header">

        <h2>Data Kategori</h2>

        <?php if (is_admin()): ?>

            <a
                href="create.php"
                class="btn btn-primary"
            >
                + Tambah Kategori
            </a>

        <?php endif; ?>

    </div>


    <div class="table-responsive">

        <table>

            <thead>

                <tr>
                    <th>No</th>
                    <th>Nama Kategori</th>
                    <th>Jumlah Produk</th>
                    <th>Dibuat</th>

                    <?php if (is_admin()): ?>
                        <th>Aksi</th>
                    <?php endif; ?>

                </tr>

            </thead>


            <tbody>

                <?php if (count($categories) > 0): ?>

                    <?php foreach ($categories as $index => $category): ?>

                        <tr>

                            <td>
                                <?= $index + 1 ?>
                            </td>

                            <td>
                                <?= e($category['name']) ?>
                            </td>

                            <td>
                                <?= e($category['total_products']) ?>
                            </td>

                            <td>
                                <?= e($category['created_at']) ?>
                            </td>

                            <?php if (is_admin()): ?>

                                <td>

                                    <a
                                        href="edit.php?id=<?= e($category['id']) ?>"
                                        class="btn btn-small btn-warning"
                                    >
                                        Edit
                                    </a>

                                    <a
                                        href="delete.php?id=<?= e($category['id']) ?>"
                                        class="btn btn-small btn-danger"
                                        onclick="return confirm('Yakin ingin menghapus kategori ini?')"
                                    >
                                        Hapus
                                    </a>

                                </td>

                            <?php endif; ?>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="<?= is_admin() ? 5 : 4 ?>"
                            class="text-center"
                        >
                            Belum ada kategori.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>