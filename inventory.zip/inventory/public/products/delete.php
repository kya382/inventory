<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';

require_admin();

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {

    $_SESSION['error'] = 'ID produk tidak valid.';

    header('Location: index.php');
    exit;
}


// Cek apakah produk mempunyai riwayat stok

$stmt = $pdo->prepare("
    SELECT COUNT(*) AS total
    FROM stock_movements
    WHERE product_id = ?
");

$stmt->execute([$id]);

$totalMovements = $stmt->fetch()['total'];


// Cek apakah produk mempunyai supplier

$stmt = $pdo->prepare("
    SELECT COUNT(*) AS total
    FROM product_suppliers
    WHERE product_id = ?
");

$stmt->execute([$id]);

$totalSuppliers = $stmt->fetch()['total'];


if ($totalMovements > 0) {

    $_SESSION['error'] =
        'Produk tidak dapat dihapus karena sudah memiliki riwayat stok.';

    header('Location: index.php');
    exit;
}


if ($totalSuppliers > 0) {

    $_SESSION['error'] =
        'Produk tidak dapat dihapus karena masih memiliki supplier.';

    header('Location: index.php');
    exit;
}


// Hapus produk

$stmt = $pdo->prepare("
    DELETE FROM products
    WHERE id = ?
");

$stmt->execute([$id]);

$_SESSION['success'] = 'Produk berhasil dihapus.';

header('Location: index.php');
exit;