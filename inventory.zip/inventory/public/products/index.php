<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_login();

$page_title = 'Produk';

$search = trim($_GET['search'] ?? '');
$category_id = (int) ($_GET['category_id'] ?? 0);
$sort = $_GET['sort'] ?? 'name';
$order = strtoupper($_GET['order'] ?? 'ASC');


// Kolom yang boleh digunakan untuk sorting
$allowedSort = [
    'name'  => 'p.name',
    'price' => 'p.price',
    'stock' => 'p.stock',
    'sku'   => 'p.sku'
];

if (!isset($allowedSort[$sort])) {
    $sort = 'name';
}

if (!in_array($order, ['ASC', 'DESC'], true)) {
    $order = 'ASC';
}


// ================================
// PAGINATION
// ================================

$perPage = 10;

$page = max(1, (int) ($_GET['page'] ?? 1));

$offset = ($page - 1) * $perPage;


// ================================
// WHERE
// ================================

$where = [];
$params = [];

if ($search !== '') {

    $where[] = "
        (
            p.name LIKE ?
            OR p.sku LIKE ?
        )
    ";

    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}

if ($category_id > 0) {

    $where[] = "p.category_id = ?";

    $params[] = $category_id;
}

$whereSQL = '';

if (!empty($where)) {
    $whereSQL = 'WHERE ' . implode(' AND ', $where);
}


// ================================
// TOTAL DATA
// ================================

$countSQL = "
    SELECT COUNT(*)
    FROM products p
    $whereSQL
";

$stmt = $pdo->prepare($countSQL);

$stmt->execute($params);

$totalProducts = (int) $stmt->fetchColumn();

$totalPages = max(1, ceil($totalProducts / $perPage));


// ================================
// DATA PRODUK
// ================================

$sql = "
    SELECT
        p.id,
        p.sku,
        p.name,
        p.price,
        p.stock,
        p.minimum_stock,
        c.name AS category_name
    FROM products p

    INNER JOIN categories c
        ON c.id = p.category_id

    $whereSQL

    ORDER BY {$allowedSort[$sort]} $order

    LIMIT $perPage OFFSET $offset
";

$stmt = $pdo->prepare($sql);

$stmt->execute($params);

$products = $stmt->fetchAll();


// ================================
// DATA KATEGORI
// ================================

$stmt = $pdo->query("
    SELECT id, name
    FROM categories
    ORDER BY name ASC
");

$categories = $stmt->fetchAll();

include __DIR__ . '/../../views/header.php';

?>


<div class="card">

    <div class="card-header">

        <h2>Data Produk</h2>

        <?php if (is_admin()): ?>

            <a
                href="create.php"
                class="btn btn-primary"
            >
                + Tambah Produk
            </a>

        <?php endif; ?>

    </div>


    <!-- ================================ -->
    <!-- SEARCH & FILTER -->
    <!-- ================================ -->

    <form method="GET" class="filter-form">

        <div class="form-group">

            <label for="search">
                Cari Produk
            </label>

            <input
                type="text"
                id="search"
                name="search"
                value="<?= e($search) ?>"
                placeholder="Cari nama atau SKU..."
            >

        </div>


        <div class="form-group">

            <label for="category_id">
                Kategori
            </label>

            <select
                id="category_id"
                name="category_id"
            >

                <option value="0">
                    Semua Kategori
                </option>

                <?php foreach ($categories as $category): ?>

                    <option
                        value="<?= e($category['id']) ?>"
                        <?= $category_id == $category['id'] ? 'selected' : '' ?>
                    >
                        <?= e($category['name']) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="form-group">

            <label for="sort">
                Urutkan
            </label>

            <select
                id="sort"
                name="sort"
            >

                <option
                    value="name"
                    <?= $sort === 'name' ? 'selected' : '' ?>
                >
                    Nama
                </option>

                <option
                    value="price"
                    <?= $sort === 'price' ? 'selected' : '' ?>
                >
                    Harga
                </option>

                <option
                    value="stock"
                    <?= $sort === 'stock' ? 'selected' : '' ?>
                >
                    Stok
                </option>

                <option
                    value="sku"
                    <?= $sort === 'sku' ? 'selected' : '' ?>
                >
                    SKU
                </option>

            </select>

        </div>


        <div class="form-group">

            <label for="order">
                Urutan
            </label>

            <select
                id="order"
                name="order"
            >

                <option
                    value="ASC"
                    <?= $order === 'ASC' ? 'selected' : '' ?>
                >
                    Naik
                </option>

                <option
                    value="DESC"
                    <?= $order === 'DESC' ? 'selected' : '' ?>
                >
                    Turun
                </option>

            </select>

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Cari
            </button>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                Reset
            </a>

        </div>

    </form>


    <!-- ================================ -->
    <!-- TABLE -->
    <!-- ================================ -->

    <div class="table-responsive">

        <table>

            <thead>

                <tr>

                    <th>No</th>

                    <th>SKU</th>

                    <th>Nama Produk</th>

                    <th>Kategori</th>

                    <th>Harga</th>

                    <th>Stok</th>

                    <th>Minimum</th>

                    <th>Status</th>

                    <?php if (is_admin()): ?>
                        <th>Aksi</th>
                    <?php endif; ?>

                </tr>

            </thead>


            <tbody>

                <?php if (count($products) > 0): ?>

                    <?php foreach ($products as $index => $product): ?>

                        <tr>

                            <td>
                                <?= $offset + $index + 1 ?>
                            </td>

                            <td>
                                <?= e($product['sku']) ?>
                            </td>

                            <td>
                                <?= e($product['name']) ?>
                            </td>

                            <td>
                                <?= e($product['category_name']) ?>
                            </td>

                            <td>
                                Rp <?= number_format(
                                    $product['price'],
                                    0,
                                    ',',
                                    '.'
                                ) ?>
                            </td>

                            <td>
                                <?= e($product['stock']) ?>
                            </td>

                            <td>
                                <?= e($product['minimum_stock']) ?>
                            </td>

                            <td>

                                <?php if (
                                    $product['stock']
                                    <=
                                    $product['minimum_stock']
                                ): ?>

                                    <span class="badge badge-danger">
                                        Stok Menipis
                                    </span>

                                <?php else: ?>

                                    <span class="badge badge-success">
                                        Aman
                                    </span>

                                <?php endif; ?>

                            </td>


                            <?php if (is_admin()): ?>

                                <td>

                                    <a
                                        href="edit.php?id=<?= e($product['id']) ?>"
                                        class="btn btn-small btn-warning"
                                    >
                                        Edit
                                    </a>

                                    <a
                                        href="delete.php?id=<?= e($product['id']) ?>"
                                        class="btn btn-small btn-danger"
                                        onclick="return confirm('Yakin ingin menghapus produk ini?')"
                                    >
                                        Hapus
                                    </a>

                                </td>

                            <?php endif; ?>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="<?= is_admin() ? 9 : 8 ?>"
                            class="text-center"
                        >
                            Produk tidak ditemukan.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>


    <!-- ================================ -->
    <!-- PAGINATION -->
    <!-- ================================ -->

    <?php if ($totalPages > 1): ?>

        <div class="pagination">

            <?php for ($i = 1; $i <= $totalPages; $i++): ?>

                <a
                    href="?search=<?= urlencode($search) ?>&category_id=<?= $category_id ?>&sort=<?= urlencode($sort) ?>&order=<?= urlencode($order) ?>&page=<?= $i ?>"
                    class="<?= $page == $i ? 'active' : '' ?>"
                >
                    <?= $i ?>
                </a>

            <?php endfor; ?>

        </div>

    <?php endif; ?>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>