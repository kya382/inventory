<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_admin();

$page_title = 'Edit Produk';

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {

    $_SESSION['error'] = 'ID produk tidak valid.';

    header('Location: index.php');
    exit;
}


// Ambil produk

$stmt = $pdo->prepare("
    SELECT *
    FROM products
    WHERE id = ?
");

$stmt->execute([$id]);

$product = $stmt->fetch();

if (!$product) {

    $_SESSION['error'] = 'Produk tidak ditemukan.';

    header('Location: index.php');
    exit;
}


// Ambil kategori

$stmt = $pdo->query("
    SELECT id, name
    FROM categories
    ORDER BY name ASC
");

$categories = $stmt->fetchAll();


$error = '';

$sku = $product['sku'];
$name = $product['name'];
$category_id = $product['category_id'];
$price = $product['price'];
$stock = $product['stock'];
$minimum_stock = $product['minimum_stock'];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $sku = trim($_POST['sku'] ?? '');
    $name = trim($_POST['name'] ?? '');
    $category_id = (int) ($_POST['category_id'] ?? 0);
    $price = $_POST['price'] ?? '';
    $stock = (int) ($_POST['stock'] ?? 0);
    $minimum_stock = (int) ($_POST['minimum_stock'] ?? 5);


    if ($sku === '') {

        $error = 'SKU wajib diisi.';

    } elseif ($name === '') {

        $error = 'Nama produk wajib diisi.';

    } elseif ($category_id <= 0) {

        $error = 'Kategori wajib dipilih.';

    } elseif (!is_numeric($price) || $price < 0) {

        $error = 'Harga tidak boleh negatif.';

    } elseif ($stock < 0) {

        $error = 'Stok tidak boleh negatif.';

    } elseif ($minimum_stock < 0) {

        $error = 'Minimum stok tidak boleh negatif.';

    } else {

        // Cek SKU tidak dipakai produk lain

        $stmt = $pdo->prepare("
            SELECT id
            FROM products
            WHERE sku = ?
            AND id != ?
            LIMIT 1
        ");

        $stmt->execute([$sku, $id]);

        if ($stmt->fetch()) {

            $error = 'SKU sudah digunakan oleh produk lain.';

        } else {

            $stmt = $pdo->prepare("
                SELECT id
                FROM categories
                WHERE id = ?
                LIMIT 1
            ");

            $stmt->execute([$category_id]);

            if (!$stmt->fetch()) {

                $error = 'Kategori tidak ditemukan.';

            } else {

                $stmt = $pdo->prepare("
                    UPDATE products
                    SET
                        category_id = ?,
                        sku = ?,
                        name = ?,
                        price = ?,
                        stock = ?,
                        minimum_stock = ?
                    WHERE id = ?
                ");

                $stmt->execute([
                    $category_id,
                    $sku,
                    $name,
                    $price,
                    $stock,
                    $minimum_stock,
                    $id
                ]);

                $_SESSION['success'] =
                    'Produk berhasil diperbarui.';

                header('Location: index.php');
                exit;
            }
        }
    }
}

include __DIR__ . '/../../views/header.php';

?>


<div class="card">

    <div class="card-header">

        <h2>Edit Produk</h2>

    </div>


    <?php if ($error !== ''): ?>

        <div class="alert alert-danger">
            <?= e($error) ?>
        </div>

    <?php endif; ?>


    <form method="POST">

        <div class="form-group">

            <label for="sku">
                SKU
            </label>

            <input
                type="text"
                id="sku"
                name="sku"
                value="<?= e($sku) ?>"
                required
            >

        </div>


        <div class="form-group">

            <label for="name">
                Nama Produk
            </label>

            <input
                type="text"
                id="name"
                name="name"
                value="<?= e($name) ?>"
                required
            >

        </div>


        <div class="form-group">

            <label for="category_id">
                Kategori
            </label>

            <select
                id="category_id"
                name="category_id"
                required
            >

                <?php foreach ($categories as $category): ?>

                    <option
                        value="<?= e($category['id']) ?>"
                        <?= $category_id == $category['id'] ? 'selected' : '' ?>
                    >
                        <?= e($category['name']) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="form-group">

            <label for="price">
                Harga
            </label>

            <input
                type="number"
                id="price"
                name="price"
                value="<?= e($price) ?>"
                min="0"
                step="0.01"
                required
            >

        </div>


        <div class="form-group">

            <label for="stock">
                Stok
            </label>

            <input
                type="number"
                id="stock"
                name="stock"
                value="<?= e($stock) ?>"
                min="0"
                required
            >

        </div>


        <div class="form-group">

            <label for="minimum_stock">
                Minimum Stok
            </label>

            <input
                type="number"
                id="minimum_stock"
                name="minimum_stock"
                value="<?= e($minimum_stock) ?>"
                min="0"
                required
            >

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Update
            </button>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                Kembali
            </a>

        </div>

    </form>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>