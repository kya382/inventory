<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_admin();

$page_title = 'Edit Pengguna';

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {

    $_SESSION['error'] = 'ID pengguna tidak valid.';

    header('Location: index.php');
    exit;
}


// Ambil data pengguna

$stmt = $pdo->prepare("
    SELECT *
    FROM users
    WHERE id = ?
");

$stmt->execute([$id]);

$user = $stmt->fetch();

if (!$user) {

    $_SESSION['error'] = 'Pengguna tidak ditemukan.';

    header('Location: index.php');
    exit;
}


$error = '';

$username = $user['username'];
$role = $user['role'];


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $role = $_POST['role'] ?? 'staff';
    $password = $_POST['password'] ?? '';


    if ($username === '') {

        $error = 'Username wajib diisi.';

    } elseif (strlen($username) < 3) {

        $error = 'Username minimal 3 karakter.';

    } elseif (!in_array($role, ['admin', 'staff'], true)) {

        $error = 'Role tidak valid.';

    } else {

        // Cek username

        $stmt = $pdo->prepare("
            SELECT id
            FROM users
            WHERE username = ?
            AND id != ?
            LIMIT 1
        ");

        $stmt->execute([
            $username,
            $id
        ]);

        if ($stmt->fetch()) {

            $error = 'Username sudah digunakan.';

        } else {

            if ($password !== '') {

                if (strlen($password) < 6) {

                    $error =
                        'Password baru minimal 6 karakter.';

                } else {

                    $hashedPassword = password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                    $stmt = $pdo->prepare("
                        UPDATE users
                        SET
                            username = ?,
                            password = ?,
                            role = ?
                        WHERE id = ?
                    ");

                    $stmt->execute([
                        $username,
                        $hashedPassword,
                        $role,
                        $id
                    ]);
                }

            } else {

                $stmt = $pdo->prepare("
                    UPDATE users
                    SET
                        username = ?,
                        role = ?
                    WHERE id = ?
                ");

                $stmt->execute([
                    $username,
                    $role,
                    $id
                ]);
            }


            if ($error === '') {

                $_SESSION['success'] =
                    'Pengguna berhasil diperbarui.';

                /*
                 * Kalau admin sedang mengubah akun
                 * yang sedang digunakan, session juga
                 * harus diperbarui.
                 */

                if ($id == current_user()['id']) {

                    $_SESSION['user']['username'] = $username;
                    $_SESSION['user']['role'] = $role;

                }

                header('Location: index.php');
                exit;
            }
        }
    }
}

include __DIR__ . '/../../views/header.php';

?>

<div class="card">

    <div class="card-header">

        <h2>Edit Pengguna</h2>

    </div>


    <?php if ($error !== ''): ?>

        <div class="alert alert-danger">
            <?= e($error) ?>
        </div>

    <?php endif; ?>


    <form method="POST">

        <div class="form-group">

            <label for="username">
                Username
            </label>

            <input
                type="text"
                id="username"
                name="username"
                value="<?= e($username) ?>"
                required
            >

        </div>


        <div class="form-group">

            <label for="password">
                Password Baru
            </label>

            <input
                type="password"
                id="password"
                name="password"
                placeholder="Kosongkan jika tidak ingin mengubah password"
            >

        </div>


        <div class="form-group">

            <label for="role">
                Role
            </label>

            <select
                id="role"
                name="role"
                required
            >

                <option
                    value="staff"
                    <?= $role === 'staff' ? 'selected' : '' ?>
                >
                    Staff
                </option>

                <option
                    value="admin"
                    <?= $role === 'admin' ? 'selected' : '' ?>
                >
                    Admin
                </option>

            </select>

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Update
            </button>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                Kembali
            </a>

        </div>

    </form>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>