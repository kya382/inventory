<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_admin();

$page_title = 'Pengguna';

$stmt = $pdo->query("
    SELECT
        id,
        username,
        role,
        created_at
    FROM users
    ORDER BY username ASC
");

$users = $stmt->fetchAll();

include __DIR__ . '/../../views/header.php';

?>

<div class="card">

    <div class="card-header">

        <h2>Data Pengguna</h2>

        <a
            href="create.php"
            class="btn btn-primary"
        >
            + Tambah Pengguna
        </a>

    </div>


    <div class="table-responsive">

        <table>

            <thead>

                <tr>
                    <th>No</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Dibuat</th>
                    <th>Aksi</th>
                </tr>

            </thead>


            <tbody>

                <?php if (count($users) > 0): ?>

                    <?php foreach ($users as $index => $user): ?>

                        <tr>

                            <td>
                                <?= $index + 1 ?>
                            </td>

                            <td>
                                <?= e($user['username']) ?>
                            </td>

                            <td>

                                <?php if ($user['role'] === 'admin'): ?>

                                    <span class="badge badge-success">
                                        Admin
                                    </span>

                                <?php else: ?>

                                    <span class="badge">
                                        Staff
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>
                                <?= e($user['created_at']) ?>
                            </td>

                            <td>

                                <a
                                    href="edit.php?id=<?= e($user['id']) ?>"
                                    class="btn btn-small btn-warning"
                                >
                                    Edit
                                </a>

                                <?php if ($user['id'] != current_user()['id']): ?>

                                    <a
                                        href="delete.php?id=<?= e($user['id']) ?>"
                                        class="btn btn-small btn-danger"
                                        onclick="return confirm('Yakin ingin menghapus pengguna ini?')"
                                    >
                                        Hapus
                                    </a>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="5"
                            class="text-center"
                        >
                            Belum ada pengguna.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>