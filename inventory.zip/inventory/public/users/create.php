<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_admin();

$page_title = 'Tambah Pengguna';

$error = '';

$username = '';
$password = '';
$role = 'staff';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'staff';


    if ($username === '') {

        $error = 'Username wajib diisi.';

    } elseif (strlen($username) < 3) {

        $error = 'Username minimal 3 karakter.';

    } elseif ($password === '') {

        $error = 'Password wajib diisi.';

    } elseif (strlen($password) < 6) {

        $error = 'Password minimal 6 karakter.';

    } elseif (!in_array($role, ['admin', 'staff'], true)) {

        $error = 'Role tidak valid.';

    } else {

        // Cek username

        $stmt = $pdo->prepare("
            SELECT id
            FROM users
            WHERE username = ?
            LIMIT 1
        ");

        $stmt->execute([$username]);

        if ($stmt->fetch()) {

            $error = 'Username sudah digunakan.';

        } else {

            // Hash password

            $hashedPassword = password_hash(
                $password,
                PASSWORD_DEFAULT
            );


            $stmt = $pdo->prepare("
                INSERT INTO users
                (
                    username,
                    password,
                    role
                )
                VALUES (?, ?, ?)
            ");

            $stmt->execute([
                $username,
                $hashedPassword,
                $role
            ]);


            $_SESSION['success'] =
                'Pengguna berhasil ditambahkan.';

            header('Location: index.php');
            exit;
        }
    }
}

include __DIR__ . '/../../views/header.php';

?>

<div class="card">

    <div class="card-header">

        <h2>Tambah Pengguna</h2>

    </div>


    <?php if ($error !== ''): ?>

        <div class="alert alert-danger">
            <?= e($error) ?>
        </div>

    <?php endif; ?>


    <form method="POST">

        <div class="form-group">

            <label for="username">
                Username
            </label>

            <input
                type="text"
                id="username"
                name="username"
                value="<?= e($username) ?>"
                placeholder="Masukkan username"
                required
            >

        </div>


        <div class="form-group">

            <label for="password">
                Password
            </label>

            <input
                type="password"
                id="password"
                name="password"
                placeholder="Minimal 6 karakter"
                required
            >

        </div>


        <div class="form-group">

            <label for="role">
                Role
            </label>

            <select
                id="role"
                name="role"
                required
            >

                <option
                    value="staff"
                    <?= $role === 'staff' ? 'selected' : '' ?>
                >
                    Staff
                </option>

                <option
                    value="admin"
                    <?= $role === 'admin' ? 'selected' : '' ?>
                >
                    Admin
                </option>

            </select>

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Simpan
            </button>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                Kembali
            </a>

        </div>

    </form>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>