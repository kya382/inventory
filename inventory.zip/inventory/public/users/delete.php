<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';

require_admin();

$id = (int) ($_GET['id'] ?? 0);

if ($id <= 0) {

    $_SESSION['error'] = 'ID pengguna tidak valid.';

    header('Location: index.php');
    exit;
}


// Tidak boleh menghapus akun sendiri

if ($id == current_user()['id']) {

    $_SESSION['error'] =
        'Akun yang sedang digunakan tidak dapat dihapus.';

    header('Location: index.php');
    exit;
}


// Cek apakah user mempunyai riwayat transaksi stok

$stmt = $pdo->prepare("
    SELECT COUNT(*) AS total
    FROM stock_movements
    WHERE user_id = ?
");

$stmt->execute([$id]);

$totalMovements = $stmt->fetch()['total'];


if ($totalMovements > 0) {

    $_SESSION['error'] =
        'Pengguna tidak dapat dihapus karena memiliki riwayat transaksi stok.';

    header('Location: index.php');
    exit;
}


// Hapus user

$stmt = $pdo->prepare("
    DELETE FROM users
    WHERE id = ?
");

$stmt->execute([$id]);

$_SESSION['success'] =
    'Pengguna berhasil dihapus.';

header('Location: index.php');
exit;