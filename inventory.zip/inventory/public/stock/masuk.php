<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_login();

$page_title = 'Barang Masuk';

$error = '';

$product_id = '';
$quantity = '';
$note = '';


// Ambil daftar produk

$stmt = $pdo->query("
    SELECT
        id,
        sku,
        name,
        stock
    FROM products
    ORDER BY name ASC
");

$products = $stmt->fetchAll();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $product_id = (int) ($_POST['product_id'] ?? 0);
    $quantity = (int) ($_POST['quantity'] ?? 0);
    $note = trim($_POST['note'] ?? '');


    if ($product_id <= 0) {

        $error = 'Produk wajib dipilih.';

    } elseif ($quantity <= 0) {

        $error = 'Jumlah barang harus lebih dari 0.';

    } else {

        try {

            $pdo->beginTransaction();


            // Kunci data produk selama transaksi

            $stmt = $pdo->prepare("
                SELECT id, stock
                FROM products
                WHERE id = ?
                FOR UPDATE
            ");

            $stmt->execute([$product_id]);

            $product = $stmt->fetch();


            if (!$product) {

                throw new Exception('Produk tidak ditemukan.');

            }


            // Tambah stok

            $stmt = $pdo->prepare("
                UPDATE products
                SET stock = stock + ?
                WHERE id = ?
            ");

            $stmt->execute([
                $quantity,
                $product_id
            ]);


            // Catat riwayat

            $stmt = $pdo->prepare("
                INSERT INTO stock_movements
                (
                    product_id,
                    user_id,
                    type,
                    quantity,
                    note
                )
                VALUES (?, ?, 'IN', ?, ?)
            ");

            $stmt->execute([
                $product_id,
                current_user()['id'],
                $quantity,
                $note
            ]);


            $pdo->commit();


            $_SESSION['success'] =
                'Barang masuk berhasil dicatat.';

            header('Location: index.php');
            exit;


        } catch (Exception $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $error = $e->getMessage();
        }
    }
}

include __DIR__ . '/../../views/header.php';

?>


<div class="card">

    <div class="card-header">

        <h2>Barang Masuk</h2>

    </div>


    <?php if ($error !== ''): ?>

        <div class="alert alert-danger">
            <?= e($error) ?>
        </div>

    <?php endif; ?>


    <form method="POST">

        <div class="form-group">

            <label for="product_id">
                Produk
            </label>

            <select
                id="product_id"
                name="product_id"
                required
            >

                <option value="">
                    -- Pilih Produk --
                </option>

                <?php foreach ($products as $product): ?>

                    <option
                        value="<?= e($product['id']) ?>"
                        <?= $product_id == $product['id'] ? 'selected' : '' ?>
                    >
                        <?= e($product['sku']) ?>
                        -
                        <?= e($product['name']) ?>
                        (Stok: <?= e($product['stock']) ?>)
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="form-group">

            <label for="quantity">
                Jumlah Barang
            </label>

            <input
                type="number"
                id="quantity"
                name="quantity"
                value="<?= e($quantity) ?>"
                min="1"
                required
            >

        </div>


        <div class="form-group">

            <label for="note">
                Keterangan
            </label>

            <textarea
                id="note"
                name="note"
                rows="4"
                placeholder="Contoh: Pembelian dari supplier"
            ><?= e($note) ?></textarea>

        </div>


        <div class="form-actions">

            <button
                type="submit"
                class="btn btn-primary"
            >
                Simpan Barang Masuk
            </button>

            <a
                href="index.php"
                class="btn btn-secondary"
            >
                Kembali
            </a>

        </div>

    </form>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>