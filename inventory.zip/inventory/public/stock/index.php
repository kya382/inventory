<?php

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../helpers/auth.php';
require_once __DIR__ . '/../../helpers/escape.php';

require_login();

$page_title = 'Riwayat Stok';

$stmt = $pdo->query("
    SELECT
        sm.id,
        sm.type,
        sm.quantity,
        sm.note,
        sm.created_at,
        p.sku,
        p.name AS product_name,
        u.username
    FROM stock_movements sm
    INNER JOIN products p
        ON p.id = sm.product_id
    INNER JOIN users u
        ON u.id = sm.user_id
    ORDER BY sm.created_at DESC
");

$movements = $stmt->fetchAll();

include __DIR__ . '/../../views/header.php';

?>

<div class="card">

    <div class="card-header">

        <h2>Riwayat Stok</h2>

        <div>

            <a
                href="masuk.php"
                class="btn btn-primary"
            >
                + Barang Masuk
            </a>

            <a
                href="keluar.php"
                class="btn btn-danger"
            >
                - Barang Keluar
            </a>

        </div>

    </div>


    <div class="table-responsive">

        <table>

            <thead>

                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>SKU</th>
                    <th>Produk</th>
                    <th>Jenis</th>
                    <th>Jumlah</th>
                    <th>Keterangan</th>
                    <th>Petugas</th>
                </tr>

            </thead>


            <tbody>

                <?php if (count($movements) > 0): ?>

                    <?php foreach ($movements as $index => $movement): ?>

                        <tr>

                            <td>
                                <?= $index + 1 ?>
                            </td>

                            <td>
                                <?= e($movement['created_at']) ?>
                            </td>

                            <td>
                                <?= e($movement['sku']) ?>
                            </td>

                            <td>
                                <?= e($movement['product_name']) ?>
                            </td>

                            <td>

                                <?php if ($movement['type'] === 'IN'): ?>

                                    <span class="badge badge-success">
                                        Barang Masuk
                                    </span>

                                <?php else: ?>

                                    <span class="badge badge-danger">
                                        Barang Keluar
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td>
                                <?= e($movement['quantity']) ?>
                            </td>

                            <td>
                                <?= e($movement['note'] ?? '-') ?>
                            </td>

                            <td>
                                <?= e($movement['username']) ?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="8"
                            class="text-center"
                        >
                            Belum ada riwayat stok.
                        </td>

                    </tr>

                <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>


<?php include __DIR__ . '/../../views/footer.php'; ?>