<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../helpers/escape.php';


// Kalau sudah login, langsung ke dashboard
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}


$error = '';

$username = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';


    if ($username === '' || $password === '') {

        $error = 'Username dan password wajib diisi.';

    } else {

        $stmt = $pdo->prepare("
            SELECT
                id,
                username,
                password,
                role
            FROM users
            WHERE username = ?
            LIMIT 1
        ");

        $stmt->execute([$username]);

        $user = $stmt->fetch();


        if (
            $user &&
            password_verify($password, $user['password'])
        ) {

            // Membuat session ID baru setelah login
            session_regenerate_id(true);

            $_SESSION['user'] = [
                'id' => $user['id'],
                'username' => $user['username'],
                'role' => $user['role']
            ];

            header('Location: dashboard.php');
            exit;

        } else {

            $error = 'Username atau password salah.';

        }
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Login - Inventory Management</title>

    <link
        rel="stylesheet"
        href="/inventory/assets/css/style.css"
    >

</head>


<body class="login-body">


<div class="login-container">

    <div class="login-card">

        <div class="login-header">

            <h1>Inventory Management</h1>

            <p>
                Silakan login untuk melanjutkan
            </p>

        </div>


        <?php if ($error !== ''): ?>

            <div class="alert alert-danger">

                <?= e($error) ?>

            </div>

        <?php endif; ?>


        <form method="POST">

            <div class="form-group">

                <label for="username">
                    Username
                </label>

                <input
                    type="text"
                    id="username"
                    name="username"
                    value="<?= e($username) ?>"
                    placeholder="Masukkan username"
                    required
                >

            </div>


            <div class="form-group">

                <label for="password">
                    Password
                </label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Masukkan password"
                    required
                >

            </div>


            <button
                type="submit"
                class="btn btn-primary btn-full"
            >
                Login
            </button>

        </form>


        <div class="login-info">

            <p>
                <strong>Admin:</strong>
                admin / password
            </p>

            <p>
                <strong>Staff:</strong>
                staff / password
            </p>

        </div>

    </div>

</div>


</body>

</html>