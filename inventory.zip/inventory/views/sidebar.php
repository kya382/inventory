<?php

$currentUser = current_user();

?>

<aside class="sidebar">

    <div class="sidebar-logo">

        <h2>Inventory</h2>

        <p>Management System</p>

    </div>


    <nav class="sidebar-menu">

        <div class="menu-title">
            MENU UTAMA
        </div>

        <a href="/inventory/public/dashboard.php">
            Dashboard
        </a>


        <div class="menu-title">
            MASTER DATA
        </div>

        <a href="/inventory/public/categories/index.php">
            Kategori
        </a>

        <a href="/inventory/public/products/index.php">
            Produk
        </a>

        <a href="/inventory/public/suppliers/index.php">
            Supplier
        </a>


        <div class="menu-title">
            TRANSAKSI
        </div>

        <a href="/inventory/public/stock/index.php">
            Riwayat Stok
        </a>

        <a href="/inventory/public/stock/masuk.php">
            Stok Masuk
        </a>

        <a href="/inventory/public/stock/keluar.php">
            Stok Keluar
        </a>


        <?php if (is_admin()): ?>

            <div class="menu-title">
                ADMIN
            </div>

            <a href="/inventory/public/users/index.php">
                Pengguna
            </a>

        <?php endif; ?>


        <div class="menu-title">
            AKUN
        </div>

        <a href="/inventory/public/logout.php">
            Logout
        </a>

    </nav>

</aside>