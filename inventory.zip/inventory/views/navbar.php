<?php

$currentUser = current_user();

?>

<header class="topbar">

    <div>

        <h1>
            <?= isset($page_title)
                ? e($page_title)
                : 'Inventory Management'
            ?>
        </h1>

    </div>


    <div class="user-info">

        <span>
            <?= e($currentUser['username']) ?>
        </span>

        <span class="role-badge">

            <?= e(
                ucfirst($currentUser['role'])
            ) ?>

        </span>

    </div>

</header>