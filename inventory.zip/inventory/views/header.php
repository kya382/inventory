<?php
require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../helpers/escape.php';

require_login();

$currentUser = current_user();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= e($title ?? 'Inventory Management System') ?></title>

    <link rel="stylesheet" href="/inventory/assets/css/style.css">
</head>

<body>

<div class="app-container">

    <!-- SIDEBAR -->
    <aside class="sidebar">

        <div class="sidebar-logo">
            <h2>Inventory</h2>
            <p>Management System</p>
        </div>

        <nav class="sidebar-menu">

            <a href="/inventory/public/dashboard.php">
                Dashboard
            </a>

            <div class="menu-title">
                MASTER DATA
            </div>

            <a href="/inventory/public/categories/index.php">
                Kategori
            </a>

            <a href="/inventory/public/products/index.php">
                Produk
            </a>

            <a href="/inventory/public/suppliers/index.php">
                Supplier
            </a>

            <div class="menu-title">
                PERSEDIAAN
            </div>

            <a href="/inventory/public/stock/index.php">
                Riwayat Stok
            </a>

            <a href="/inventory/public/stock/masuk.php">
                Barang Masuk
            </a>

            <a href="/inventory/public/stock/keluar.php">
                Barang Keluar
            </a>

            <?php if (is_admin()): ?>

                <div class="menu-title">
                    ADMIN
                </div>

                <a href="/inventory/public/users/index.php">
                    Pengguna
                </a>

            <?php endif; ?>

            <div class="menu-title">
                AKUN
            </div>

            <a href="/inventory/public/logout.php">
                Logout
            </a>

        </nav>

    </aside>


    <!-- CONTENT -->
    <main class="main-content">

        <!-- TOPBAR -->
        <header class="topbar">

            <div>
                <h1><?= e($page_title ?? 'Dashboard') ?></h1>
            </div>

            <div class="user-info">

                <span>
                    <?= e($currentUser['username']) ?>
                </span>

                <span class="role-badge">
                    <?= e(strtoupper($currentUser['role'])) ?>
                </span>

            </div>

        </header>

        <!-- PAGE CONTENT -->
        <section class="content">

            <?php if (!empty($_SESSION['success'])): ?>

                <div class="alert alert-success">
                    <?= e($_SESSION['success']) ?>
                </div>

                <?php unset($_SESSION['success']); ?>

            <?php endif; ?>


            <?php if (!empty($_SESSION['error'])): ?>

                <div class="alert alert-danger">
                    <?= e($_SESSION['error']) ?>
                </div>

                <?php unset($_SESSION['error']); ?>

            <?php endif; ?>