CREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;

-- =========================
-- TABEL USERS
-- =========================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'staff') NOT NULL DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- TABEL CATEGORIES
-- =========================
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- TABEL PRODUCTS
-- =========================
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    sku VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    price DECIMAL(12,2) NOT NULL DEFAULT 0,
    stock INT NOT NULL DEFAULT 0,
    minimum_stock INT NOT NULL DEFAULT 5,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_products_category
        FOREIGN KEY (category_id)
        REFERENCES categories(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT chk_products_price
        CHECK (price >= 0),

    CONSTRAINT chk_products_stock
        CHECK (stock >= 0),

    CONSTRAINT chk_products_minimum_stock
        CHECK (minimum_stock >= 0)
);

-- =========================
-- TABEL SUPPLIERS
-- =========================
CREATE TABLE suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    phone VARCHAR(30),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- TABEL PRODUCT_SUPPLIERS
-- RELASI MANY TO MANY
-- =========================
CREATE TABLE product_suppliers (
    product_id INT NOT NULL,
    supplier_id INT NOT NULL,
    supplier_price DECIMAL(12,2) NOT NULL DEFAULT 0,

    PRIMARY KEY (product_id, supplier_id),

    CONSTRAINT fk_ps_product
        FOREIGN KEY (product_id)
        REFERENCES products(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_ps_supplier
        FOREIGN KEY (supplier_id)
        REFERENCES suppliers(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT chk_supplier_price
        CHECK (supplier_price >= 0)
);

-- =========================
-- TABEL STOCK MOVEMENTS
-- =========================
CREATE TABLE stock_movements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    type ENUM('IN', 'OUT') NOT NULL,
    quantity INT NOT NULL,
    note VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_stock_product
        FOREIGN KEY (product_id)
        REFERENCES products(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT fk_stock_user
        FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT chk_stock_quantity
        CHECK (quantity > 0)
);

-- =========================
-- DATA AWAL USER
-- =========================
INSERT INTO users (username, password, role)
VALUES
(
    'admin',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC5J8zqfQ8r9r0r0r0r0',
    'admin'
),
(
    'staff',
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC5J8zqfQ8r9r0r0r0r0',
    'staff'
);

-- =========================
-- DATA AWAL CATEGORY
-- =========================
INSERT INTO categories (name)
VALUES
('Elektronik'),
('Alat Tulis'),
('Peralatan Kantor'),
('Makanan'),
('Minuman');

-- =========================
-- DATA AWAL SUPPLIER
-- =========================
INSERT INTO suppliers (name, phone, address)
VALUES
('PT Sumber Jaya', '081234567890', 'Jl. Merdeka No. 10'),
('CV Maju Bersama', '082345678901', 'Jl. Pendidikan No. 20'),
('Toko Grosir Sejahtera', '083456789012', 'Jl. Pasar Baru No. 15');

-- =========================
-- DATA AWAL PRODUCTS
-- =========================
INSERT INTO products
(category_id, sku, name, price, stock, minimum_stock)
VALUES
(1, 'EL001', 'Mouse Wireless', 75000, 20, 5),
(1, 'EL002', 'Keyboard USB', 120000, 15, 5),
(2, 'AT001', 'Buku Tulis', 8000, 50, 10),
(2, 'AT002', 'Pulpen', 5000, 100, 20),
(3, 'PK001', 'Kursi Kantor', 450000, 8, 3);

-- =========================
-- RELASI PRODUCT - SUPPLIER
-- =========================
INSERT INTO product_suppliers
(product_id, supplier_id, supplier_price)
VALUES
(1, 1, 60000),
(1, 2, 62000),
(2, 1, 95000),
(3, 2, 6000),
(4, 2, 3500),
(5, 3, 380000);