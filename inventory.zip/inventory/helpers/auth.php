<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in()
{
    return isset($_SESSION['user']);
}

function current_user()
{
    return $_SESSION['user'] ?? null;
}

function require_login()
{
    if (!is_logged_in()) {
        header('Location: /inventory/public/login.php');
        exit;
    }
}

function is_admin()
{
    return is_logged_in() && ($_SESSION['user']['role'] ?? '') === 'admin';
}

function require_admin()
{
    require_login();

    if (!is_admin()) {
        http_response_code(403);
        echo '<h1>403 - Akses Ditolak</h1>';
        echo '<p>Anda tidak memiliki izin untuk mengakses halaman ini.</p>';
        exit;
    }
}

function logout_user()
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();
}