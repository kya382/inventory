<?php

function cleanText($value)
{
    return trim($value);
}

function validPositiveInt($value)
{
    return filter_var($value, FILTER_VALIDATE_INT) !== false
        && $value > 0;
}

function validNonNegativeNumber($value)
{
    return is_numeric($value) && $value >= 0;
}
?>